# Real-Time Facial Emotion Detection

This project is a real-time facial emotion detection system using OpenCV and a Convolutional Neural Network (CNN).  
It classifies facial expressions into multiple emotions such as **Happy**, **Sad**, **Angry**, **Surprise**, etc.

## 🔧 Technologies Used
- Python
- Keras + TensorFlow
- OpenCV
- NumPy
- FER2013 Dataset

## 🚀 Features
- Real-time video feed via webcam
- Emotion detection overlay on the face
- CNN model trained on FER2013
- Can be extended to support additional emotions or languages

## 🧠 How It Works
1. Face detection is performed using Haar cascades from OpenCV.
2. The CNN model classifies the cropped face image into one of the predefined emotions.
3. The detected emotion is displayed in real time over the video frame.

## ✅ Built by Pallapati Pavan Kumar

## 📦 Setup Instructions
1. Clone this repository:
   ```bash
   git clone https://github.com/your-username/emotion-detector.git
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the app:
   ```bash
   python video_emotion_color_demo.py
   ```

## 📸 Demo
Feel free to add a demo GIF or video here.

---

Made with ❤️ for AI and Computer Vision.
